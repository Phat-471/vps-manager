const { Client } = require('ssh2');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

class SSHConnection {
    constructor(config) {
        this.config = {
            host: config.host,
            port: config.port || 22,
            username: config.username,
            password: config.password,
            keepaliveInterval: 10000, // Gửi ping duy trì mỗi 10 giây
            keepaliveCountMax: 3,     // Tối đa 3 lần ping không phản hồi sẽ ngắt
            readyTimeout: 20000       // Giới hạn thời gian kết nối 20 giây
        };
        this.isLocal = this.config.host === 'localhost' || this.config.host === '127.0.0.1' || this.config.host === '0.0.0.0';
        this.client = null;
        this.isConnected = false;
    }

    /**
     * Kết nối đến VPS
     */
    connect() {
        if (this.isLocal) {
            this.isConnected = true;
            console.log('Local Mode Connection Ready');
            return Promise.resolve(true);
        }

        return new Promise((resolve, reject) => {
            this.client = new Client();

            this.client.on('ready', () => {
                this.isConnected = true;
                console.log('SSH Connected:', this.config.host);
                resolve(true);
            });

            this.client.on('error', (err) => {
                this.isConnected = false;
                console.error('SSH Error:', err.message);
                reject(err);
            });

            this.client.on('close', () => {
                this.isConnected = false;
                console.log('SSH Connection closed:', this.config.host);
            });

            try {
                this.client.connect(this.config);
            } catch (err) {
                reject(err);
            }
        });
    }

    /**
     * Ngắt kết nối
     */
    disconnect() {
        if (this.isLocal) {
            this.isConnected = false;
            return;
        }

        if (this.client) {
            this.client.end();
            this.isConnected = false;
        }
    }

    executeCommand(command) {
        // Tự động kiểm tra và thêm cơ chế đợi khóa dpkg/apt cho các lệnh apt-get hoặc apt
        if (command && (command.includes('apt-get ') || command.includes('apt ')) && !command.includes('lock-frontend') && process.platform !== 'win32') {
            const waitAptCmd = `
if [ -f /etc/debian_version ]; then
    while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1 || fuser /var/lib/dpkg/lock >/dev/null 2>&1; do
        echo ">> Đang chờ tiến trình apt khác giải phóng khóa hệ thống (dpkg lock)..."
        sleep 3
    done
fi
`;
            command = waitAptCmd + '\n' + command;
        }

        return new Promise((resolve, reject) => {
            if (!this.isConnected) {
                return reject(new Error('Connection not established'));
            }

            if (this.isLocal) {
                exec(command, (err, stdout, stderr) => {
                    resolve({
                        code: err ? (err.code || 1) : 0,
                        signal: null,
                        stdout: stdout,
                        stderr: stderr || (err ? err.message : '')
                    });
                });
                return;
            }

            this.client.exec(command, (err, stream) => {
                if (err) {
                    return reject(err);
                }

                let stdout = '';
                let stderr = '';

                stream.on('close', (code, signal) => {
                    resolve({
                        code,
                        signal,
                        stdout,
                        stderr
                    });
                });

                stream.on('data', (data) => {
                    stdout += data.toString();
                });

                stream.stderr.on('data', (data) => {
                    stderr += data.toString();
                });
            });
        });
    }

    /**
     * Đọc nội dung file
     */
    readFile(remotePath) {
        return new Promise((resolve, reject) => {
            if (!this.isConnected) {
                return reject(new Error('Connection not established'));
            }

            if (this.isLocal) {
                fs.promises.readFile(remotePath, 'utf8')
                    .then(data => resolve(data))
                    .catch(err => reject(err));
                return;
            }

            this.client.sftp((err, sftp) => {
                if (err) {
                    return reject(err);
                }

                sftp.readFile(remotePath, 'utf8', (err, data) => {
                    if (err) {
                        return reject(err);
                    }
                    resolve(data);
                });
            });
        });
    }

    /**
     * Ghi nội dung vào file
     */
    writeFile(remotePath, content) {
        return new Promise((resolve, reject) => {
            if (!this.isConnected) {
                return reject(new Error('Connection not established'));
            }

            if (this.isLocal) {
                const dir = path.dirname(remotePath);
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
                fs.promises.writeFile(remotePath, content, 'utf8')
                    .then(() => resolve(true))
                    .catch(err => reject(err));
                return;
            }

            this.client.sftp((err, sftp) => {
                if (err) {
                    return reject(err);
                }

                sftp.writeFile(remotePath, content, (err) => {
                    if (err) {
                        return reject(err);
                    }
                    resolve(true);
                });
            });
        });
    }

    /**
     * Upload file lên VPS
     */
    uploadFile(localPath, remotePath) {
        return new Promise((resolve, reject) => {
            if (!this.isConnected) {
                return reject(new Error('Connection not established'));
            }

            if (this.isLocal) {
                const dir = path.dirname(remotePath);
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
                fs.promises.copyFile(localPath, remotePath)
                    .then(() => resolve(true))
                    .catch(err => reject(err));
                return;
            }

            this.client.sftp((err, sftp) => {
                if (err) {
                    return reject(err);
                }

                sftp.fastPut(localPath, remotePath, (err) => {
                    if (err) {
                        return reject(err);
                    }
                    resolve(true);
                });
            });
        });
    }

    /**
     * Download file từ VPS
     */
    downloadFile(remotePath, localPath) {
        return new Promise((resolve, reject) => {
            if (!this.isConnected) {
                return reject(new Error('Connection not established'));
            }

            if (this.isLocal) {
                const dir = path.dirname(localPath);
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
                fs.promises.copyFile(remotePath, localPath)
                    .then(() => resolve(true))
                    .catch(err => reject(err));
                return;
            }

            this.client.sftp((err, sftp) => {
                if (err) {
                    return reject(err);
                }

                sftp.fastGet(remotePath, localPath, (err) => {
                    if (err) {
                        return reject(err);
                    }
                    resolve(true);
                });
            });
        });
    }

    /**
     * Kiểm tra file/folder có tồn tại không
     */
    exists(remotePath) {
        return new Promise((resolve, reject) => {
            if (!this.isConnected) {
                return reject(new Error('Connection not established'));
            }

            if (this.isLocal) {
                resolve(fs.existsSync(remotePath));
                return;
            }

            this.client.sftp((err, sftp) => {
                if (err) {
                    return reject(err);
                }

                sftp.stat(remotePath, (err, stats) => {
                    if (err) {
                        if (err.code === 2) { // No such file
                            resolve(false);
                        } else {
                            reject(err);
                        }
                    } else {
                        resolve(true);
                    }
                });
            });
        });
    }
}

// Connection pool để quản lý nhiều VPS connections
class SSHConnectionPool {
    constructor() {
        this.connections = new Map();
    }

    /**
     * Lấy hoặc tạo connection mới
     */
    async getConnection(vpsId, config) {
        const key = vpsId || `${config.host}:${config.username}`;

        if (this.connections.has(key)) {
            const conn = this.connections.get(key);
            if (conn.isConnected) {
                return conn;
            }
        }

        const connection = new SSHConnection(config);
        await connection.connect();
        this.connections.set(key, connection);
        return connection;
    }

    /**
     * Ngắt kết nối
     */
    disconnect(vpsId) {
        if (this.connections.has(vpsId)) {
            const conn = this.connections.get(vpsId);
            conn.disconnect();
            this.connections.delete(vpsId);
        }
    }

    /**
     * Ngắt tất cả kết nối
     */
    disconnectAll() {
        for (const [key, conn] of this.connections) {
            conn.disconnect();
        }
        this.connections.clear();
    }
}

const connectionPool = new SSHConnectionPool();

module.exports = {
    SSHConnection,
    connectionPool
};
